package com.capgemini.store.reposervices;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.capgemini.store.beans.Category;
import com.capgemini.store.beans.Product;

public interface ProductRepo extends JpaRepository<Product, Integer>,CrudRepository<Product, Integer>{
	public Product findByProductId(int productId);

	public Product findByProductName(String productName);

	public List<Product> findByCategoryOrderByProductPriceAsc(Category category);

	public List<Product> findByCategoryOrderByProductPriceDesc(Category category);
}

