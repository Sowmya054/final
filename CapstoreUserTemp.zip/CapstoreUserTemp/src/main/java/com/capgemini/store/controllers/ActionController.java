package com.capgemini.store.controllers;

import java.io.IOException;
import java.lang.ref.PhantomReference;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.store.beans.Cart;
import com.capgemini.store.beans.Category;
import com.capgemini.store.beans.Customer;
import com.capgemini.store.beans.Product;
import com.capgemini.store.exceptions.InvalidInputException;
import com.capgemini.store.exceptions.ProductUnavailableException;
import com.capgemini.store.services.CapstoreServices;

@Controller
public class ActionController {
@Autowired
private CapstoreServices capstoreServices;
private String phoneNumber;
//Customer SignUp
	@RequestMapping(value = "/addCustomer")
	public ModelAndView signUp(@ModelAttribute("customer")Customer customer) {
		//customer.setPhoneNumber(phoneNumber);
		customer=capstoreServices.signUp(customer);
		
		return new ModelAndView("now1","customer",customer);
	}
	//customer SignIn
	@RequestMapping(value = "/signInCustomer")
	public ModelAndView signIn(@RequestParam("email")String email,@RequestParam("password")String password) throws InvalidInputException {
		Customer customer=capstoreServices.customerSignIn(email, password);
		phoneNumber=customer.getPhoneNumber();
		
		return new ModelAndView("newHomePage","customer",customer);
	}

	@RequestMapping(value = "/categoryProducts")
	public ModelAndView category(@RequestParam("productId")Integer productId) throws InvalidInputException {
		//customer.setPhoneNumber(phoneNumber);
		
		Product product=capstoreServices.getProductById(productId);
		return new ModelAndView("trial","product",product);
	}

//	@RequestMapping(value = "/categoryProducts")
//	public ModelAndView productss(@ModelAttribute("category")Category category) throws InvalidInputException {
//		//customer.setPhoneNumber(phoneNumber);
//		
//		List<Product> product=capstoreServices.getProductByCategory(category);
//		return new ModelAndView("trial","product",product);
//	}


	@RequestMapping(value = "/catPro")
	public ModelAndView categoryPro(@RequestParam("productId")Integer productId) throws InvalidInputException {
		//customer.setPhoneNumber(phoneNumber);
		
		Product product=capstoreServices.getProductById(productId);
		return new ModelAndView("mainDynamic","product",product);
	}
	
	@RequestMapping(value = "/cartProo")
	public ModelAndView catPro(@RequestParam("productId")Integer productId) throws InvalidInputException, ProductUnavailableException {
		//customer.setPhoneNumber(phoneNumber);
		//System.out.println("Hello");
	System.out.println(productId);
	System.out.println(phoneNumber);
	productId=101;
		Cart cart=capstoreServices.addProductToNewCart(phoneNumber,productId ,1);
		System.out.println(phoneNumber);
		//Cart cart=capstoreServices.addProductToNewCart("phoneNumber", productId, 6);
		System.out.println(cart);
		return new ModelAndView("cart","cart",cart);
		
//		
//		Product product=capstoreServices.getProductById(productId);
//		return new ModelAndView("mainDynamic","product",product);
	}
	
	@RequestMapping(value= "/addProductToNewCart")
	public Cart addProductToNewCart(String phoneNumber,int quantity, int productId) throws InvalidInputException, ProductUnavailableException {
		return capstoreServices.addProductToNewCart(phoneNumber, productId, quantity);
	}
	


}
